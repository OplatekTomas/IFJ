import subprocess
import sys
import os


class ErrRes(object):
    def __init__(self, file=None, expected=None, result=None):
        self.file = file
        self.expected = expected
        self.result = result

scriptPath = os.getcwd()
"""example: /home/tomas/Projects/IFJ"""
execPath = scriptPath + "/IFJ"

print(execPath)

failedFiles = []

testsPath = scriptPath + "/tests"
files = os.listdir(scriptPath + "/tests")
print("Following files will be tested: ")
print(*files, sep=", ")
print("\n")
for i in files:
    lines = open(testsPath + "/" + i, "r").read()
    proc = subprocess.Popen(execPath, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
    proc.stdin.write(str.encode(lines[3:]))
    proc.stdin.close()
    proc.wait()
    if str(proc.returncode) != lines[1]:
        failedFiles.append(ErrRes(i, lines[1], proc.returncode))

if len(failedFiles) == 0:
    print("All tests finished successfully")
else:
    print(str(len(failedFiles)) + " tests failed")
    for i in failedFiles:
        print(i.file + " got result: " + str(i.result) + " expected: " + str(i.expected))





